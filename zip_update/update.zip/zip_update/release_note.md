# 🛠 修复：UI优化 + 警告清除

## 自动应用的文件（已包含在 zip）

### 1. `Navigation.kt`
- ✅ 修复 `Icons.Outlined.EventNote` deprecated 警告 → 改用 `Icons.AutoMirrored.Outlined.EventNote`

### 2. `viewmodel/AppViewModel.kt`
- ✅ 新增 `scheduleFilterMode`、`scheduleFilterId`、`scheduleFilterTitle` StateFlow
- ✅ 新增 `clearScheduleFilter()` 方法
- 用于将课表筛选状态提升到 ViewModel，供 TopAppBar 读取

### 3. `MainActivity.kt`
- ✅ TopAppBar 标题动态化：选中"李老师"后标题栏直接显示"李老师的课表"
- ✅ 筛选激活时右侧出现"× 清除"按钮，一键清除筛选
- ✅ 不再在内容区下方单独显示筛选条——节约顶部空间

---

## 需手动应用的修改（3 个文件，共 7 处改动）

### A. `ScheduleScreen.kt` — 4 处修改

**修改 1：** 在 `import androidx.compose.material.icons.filled.*` 后新增一行：
```
import androidx.compose.material.icons.automirrored.filled.*
```

**修改 2：** 在 ScheduleScreen() 的 `val screenTitle = ...` 赋值语句**之后**，`var menuOpen` 之前插入：
```kotlin
// 同步筛选状态到 ViewModel，让 TopAppBar 可读取
LaunchedEffect(filterMode, filterId) {
    vm.scheduleFilterMode.value = filterMode
    vm.scheduleFilterId.value   = filterId
}
DisposableEffect(Unit) { onDispose { vm.clearScheduleFilter() } }
```

**修改 3：** 在 Scaffold content 块 `{ inner ->` 里，**删除**以下整段（共 10 行）：
```kotlin
if (filterMode != "all") {
    Surface(color = FluentBlue.copy(alpha = 0.1f)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(screenTitle, style = MaterialTheme.typography.labelLarge, color = FluentBlue, fontWeight = FontWeight.Bold)
            TextButton(onClick = { filterMode = "all"; filterId = 0 }) { Text("清除筛选") }
        }
    }
}
```

**修改 4：** 找到 SpeedDialItem 中 `Icons.Default.ViewList`，替换为：
```kotlin
Icons.AutoMirrored.Filled.ViewList
```
（位于"切换列表视图"那行）

---

### B. `ExportScreen.kt` — 2 处修改

**修改 1：** 在 `import androidx.compose.material.icons.outlined.*` 后新增：
```
import androidx.compose.material.icons.automirrored.outlined.*
```

**修改 2：** 找到（第 233 行附近）：
```kotlin
icon = Icons.Outlined.EventNote, title = "导出上课记录（JSON）"
```
改为：
```kotlin
icon = Icons.AutoMirrored.Outlined.EventNote, title = "导出上课记录（JSON）"
```

---

### C. `CommonComponents.kt` — 1 处修改

找到（第 250 行附近）：
```kotlin
modifier = Modifier.fillMaxWidth().menuAnchor(),
```
改为：
```kotlin
modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable),
```
