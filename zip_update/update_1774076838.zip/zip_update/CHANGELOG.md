#!no-build
# docs: record deprecated Compose icons in AI rules

Added a new section "Deprecated Compose icons" to docs/readme_ai_rules.md.

Lists the two icons that produced compiler deprecation warnings:
- Icons.Outlined.MenuBook  →  Icons.AutoMirrored.Outlined.MenuBook
- Icons.Filled.ViewList    →  Icons.AutoMirrored.Filled.ViewList

Also adds a general rule: always prefer the AutoMirrored variant when one
exists, and extend the table whenever a new warning appears.

No source code changed; README.md will be regenerated automatically.
