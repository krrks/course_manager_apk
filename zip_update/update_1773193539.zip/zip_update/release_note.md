# 🔧 编译错误修复

## 修复内容

### 1. AppViewModel.kt — 函数签名与数据模型不匹配
- `addTeacher()` 旧签名 `(name, subject, phone, avatarUri)` 与 `Teacher(id,name,gender,phone,subjectIds,avatarUri,code)` 不匹配，导致 `subjectIds` 收到 `String?`
- `addSchoolClass()` 旧签名 `(name, grade, subject, headTeacherId)` 与 `SchoolClass(id,name,grade,count,headTeacherId,subject,code)` 不匹配，`count:Int` 收到 `String`
- **修复**：更新两个函数签名及内部构造调用，与数据模型完全对齐

### 2. ClassesScreen.kt — 调用了不存在的方法别名
- `vm.deleteClass()` → `vm.deleteSchoolClass()`
- `vm.updateClass()` → `vm.updateSchoolClass()`
- `vm.addClass()` → `vm.addSchoolClass()`
