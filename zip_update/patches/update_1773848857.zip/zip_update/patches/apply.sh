#!/usr/bin/env bash
set -e

SCHEDULE="app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt"
ATTENDANCE="app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt"

# ─── BUG-4 FIX ────────────────────────────────────────────────────────────────
# ScheduleScreen list view: subjectName was resolved as:
#   sub?.name ?: cl?.subject?.takeIf { it.isNotBlank() } ?: "?"
# which falls back to the potentially-stale cls.subject string.
# Replace with resolvedSubjectName() which uses subjectId FK first.
# The pattern appears in the ScheduleListView items block.

python3 - "$SCHEDULE" <<'PYEOF'
import sys, re

path = sys.argv[1]
text = open(path, encoding='utf-8').read()

# Fix 1: list view subjectName derivation (two-step: remove stale fallback lines, use resolvedSubjectName)
old = (
    'val sub      = state.subjects.find { it.id == slot.subjectId }\n'
    '                    ?: state.subjects.find { s -> state.classes.find { it.id == slot.classId }?.subject == s.name }\n'
    '                val cl       = state.classes.find { it.id == slot.classId }\n'
    '                val colorIdx = state.subjects.indexOf(sub).takeIf { it >= 0 }\n'
    '                    ?: (slot.classId % SUBJECT_COLORS.size).toInt()\n'
    '                val subColor = Color(SUBJECT_COLORS[colorIdx % SUBJECT_COLORS.size])'
)
new = (
    '// BUG-4 FIX: use resolvedSubjectName() which prioritises slot.subjectId FK\n'
    '                val cl       = state.classes.find { it.id == slot.classId }\n'
    '                val resolvedSubName = slot.resolvedSubjectName(state.subjects, state.classes)\n'
    '                val sub      = state.subjects.find { it.id == slot.subjectId }\n'
    '                val colorIdx = state.subjects.indexOf(sub).takeIf { it >= 0 }\n'
    '                    ?: (slot.classId % SUBJECT_COLORS.size).toInt()\n'
    '                val subColor = Color(SUBJECT_COLORS[colorIdx % SUBJECT_COLORS.size])'
)
if old in text:
    text = text.replace(old, new)
    print('✅ Fix 1a applied (calendar view sub derivation)')
else:
    print('⚠️  Fix 1a pattern not found – may already be applied or different whitespace')

# Fix 1b: calendar view box text uses sub?.name ?: cl?.subject ?: "?"
old1b = 'sub?.name ?: cl?.subject ?: "?",'
new1b = 'resolvedSubName,'
if old1b in text:
    text = text.replace(old1b, new1b, 1)
    print('✅ Fix 1b applied (calendar view box label)')
else:
    print('⚠️  Fix 1b pattern not found')

# Fix 2: list view items block
old2 = (
    '                val sub      = state.subjects.find { it.id == slot.subjectId }\n'
    '                    ?: state.subjects.find { s -> state.classes.find { it.id == slot.classId }?.subject == s.name }\n'
    '                val cl       = state.classes.find { it.id == slot.classId }\n'
    '                val colorIdx = state.subjects.indexOf(sub).takeIf { it >= 0 }\n'
    '                    ?: (slot.classId % SUBJECT_COLORS.size).toInt()\n'
    '                val subColor = Color(SUBJECT_COLORS[colorIdx % SUBJECT_COLORS.size])\n'
    '\n'
    '                Surface(shape = RoundedCornerShape(12.dp)'
)
new2 = (
    '// BUG-4 FIX: use resolvedSubjectName()\n'
    '                val cl       = state.classes.find { it.id == slot.classId }\n'
    '                val resolvedSubName2 = slot.resolvedSubjectName(state.subjects, state.classes)\n'
    '                val sub      = state.subjects.find { it.id == slot.subjectId }\n'
    '                val colorIdx = state.subjects.indexOf(sub).takeIf { it >= 0 }\n'
    '                    ?: (slot.classId % SUBJECT_COLORS.size).toInt()\n'
    '                val subColor = Color(SUBJECT_COLORS[colorIdx % SUBJECT_COLORS.size])\n'
    '\n'
    '                Surface(shape = RoundedCornerShape(12.dp)'
)
if old2 in text:
    text = text.replace(old2, new2, 1)
    print('✅ Fix 2a applied (list view sub derivation)')
else:
    print('⚠️  Fix 2a pattern not found')

# Fix 2b: list view uses stale fallback
old2b = 'val subjectName = sub?.name ?: cl?.subject?.takeIf { it.isNotBlank() } ?: "?"'
new2b = '// BUG-4 FIX: use resolvedSubjectName\n                            val subjectName = resolvedSubName2'
if old2b in text:
    text = text.replace(old2b, new2b, 1)
    print('✅ Fix 2b applied (list view subjectName)')
else:
    print('⚠️  Fix 2b pattern not found')

open(path, 'w', encoding='utf-8').write(text)
print(f'Done patching {path}')
PYEOF

# ─── BUG-5 FIX ────────────────────────────────────────────────────────────────
# AttendanceScreen list view (AttendanceCard): subject name displayed as:
#   sub?.name ?: cl?.subject ?: "?"
# Replace with resolvedSubjectName which uses subjectId FK first.

python3 - "$ATTENDANCE" <<'PYEOF'
import sys

path = sys.argv[1]
text = open(path, encoding='utf-8').read()

# AttendanceCard uses sub?.name ?: cl?.subject ?: "?" for its title text
old = 'Text(sub?.name ?: cl?.subject ?: "?",'
new = (
    '// BUG-5 FIX: use resolvedSubjectName() so stale cls.subject fallback is avoided\n'
    '                    Text(rec.resolvedSubjectName(state.subjects, state.classes),'
)
# state reference not available directly, use vm.state.value
# Actually in AttendanceCard we have vm.state.value via the vm parameter
old_alt = 'Text(sub?.name ?: cl?.subject ?: "?",'
# Check context: AttendanceCard has vm: AppViewModel and accesses vm.state.value
if old_alt in text:
    # Use vm.state.value.subjects and vm.state.value.classes
    new_alt = (
        '// BUG-5 FIX: resolve via subjectId FK first\n'
        '                    Text(rec.resolvedSubjectName(vm.state.value.subjects, vm.state.value.classes),'
    )
    text = text.replace(old_alt, new_alt, 1)
    print('✅ Fix BUG-5 applied (AttendanceCard title)')
else:
    print('⚠️  BUG-5 pattern not found')

open(path, 'w', encoding='utf-8').write(text)
print(f'Done patching {path}')
PYEOF

echo "✅ apply.sh completed"
