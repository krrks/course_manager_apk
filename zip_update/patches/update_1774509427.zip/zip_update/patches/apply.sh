#!/usr/bin/env bash
set -e

DIALOGS="app/src/main/java/com/school/manager/ui/screens/LessonDialogs.kt"

echo "── Patching LessonDialogs.kt ─────────────────────────────────────────────"

# 1. vm.knowledgePoint(it) → vm.knowledgePointFull(it)
sed -i 's/vm\.knowledgePoint(it)/vm.knowledgePointFull(it)/g' "$DIALOGS"
echo "  ✔ vm.knowledgePoint → vm.knowledgePointFull"

# 2. state.knowledgePoints.filter { it.id in kpIds } → kpIds.mapNotNull { vm.knowledgePointFull(it) }
sed -i 's/state\.knowledgePoints\.filter { it\.id in kpIds }/kpIds.mapNotNull { vm.knowledgePointFull(it) }/g' "$DIALOGS"
echo "  ✔ state.knowledgePoints.filter → kpIds.mapNotNull { vm.knowledgePointFull }"

# 3. kp.isCustom → kp.point.isCustom  (in knowledge-point display context)
sed -i 's/kp\.isCustom/kp.point.isCustom/g' "$DIALOGS"
echo "  ✔ kp.isCustom → kp.point.isCustom"

# 4. kp.content (as .content\b — avoid hitting unrelated 'content' vars)
#    Only 'kp.content' appears in this file's KP display sections
sed -i 's/kp\.content/kp.point.content/g' "$DIALOGS"
echo "  ✔ kp.content → kp.point.content"

# 5. Update onAddNew lambda to new (sectionId, no, content) signature
sed -i 's/onAddNew  = { grade, chapter, section, code, content ->/onAddNew  = { sectionId, no, content ->/g' "$DIALOGS"
sed -i 's/vm\.addKnowledgePoint(grade, chapter, section, code, content)/vm.addKnowledgePoint(sectionId, no, content)/g' "$DIALOGS"
echo "  ✔ onAddNew lambda signature updated"

# 6. Add allChapters/allSections params to KnowledgePointPickerSheet call
#    The call site sets allPoints = state.knowledgePoints — add the two new params before it
sed -i 's/allPoints   = state\.knowledgePoints,/allChapters = state.kpChapters,\n            allSections = state.kpSections,\n            allPoints   = state.knowledgePoints,/g' "$DIALOGS"
echo "  ✔ KnowledgePointPickerSheet call updated with allChapters + allSections"

echo ""
echo "── Patching docs/readme_structure.md ────────────────────────────────────"
sed -i 's/├── KnowledgePointsScreen\.kt/├── KnowledgePointsDialogs.kt\n│   │   ├── KnowledgePointsScreen.kt/' \
  docs/readme_structure.md
echo "  ✔ KnowledgePointsDialogs.kt added to project structure"

echo ""
echo "✅ apply.sh complete"
