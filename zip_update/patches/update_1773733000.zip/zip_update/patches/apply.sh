#!/usr/bin/env bash
set -euo pipefail

SCHEDULE="app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt"

echo "=== Patching DurationChipsCompact & InlineDurationPicker in ScheduleScreen.kt ==="

python3 - "$SCHEDULE" << 'PYEOF'
import sys, re

path = sys.argv[1]
with open(path, 'r', encoding='utf-8') as f:
    src = f.read()

# ── New DurationChipsCompact implementation ──────────────────────────────────
NEW_DURATION_CHIPS = '''/**
 * 紧凑时长选择区（时/分输入框 + 步长10分钟加减号）。
 * 移除预设 1h/1.5h/2h chips，改用 +/- 按钮调整，步长 10 分钟，默认 2h。
 */
@Composable
internal fun DurationChipsCompact(
    startTime: String,
    endTime: String,
    onEndChange: (String) -> Unit
) {
    var durMins by remember {
        mutableIntStateOf(minutesBetween(startTime, endTime).takeIf { it > 0 } ?: 120)
    }
    fun push(mins: Int) { onEndChange(addMinutesToTime(startTime.ifBlank { "08:00" }, mins)) }

    val h = durMins / 60
    val m = durMins % 60

    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment     = Alignment.CenterVertically,
        modifier              = Modifier.fillMaxWidth()
    ) {
        Text(
            "时长",
            style      = MaterialTheme.typography.labelMedium,
            color      = FluentBlue,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(Modifier.width(4.dp))

        // 时 输入框
        OutlinedTextField(
            value         = h.toString(),
            onValueChange = { raw ->
                val newH = raw.filter { it.isDigit() }.toIntOrNull()?.coerceIn(0, 23) ?: h
                durMins  = newH * 60 + m
                push(durMins)
            },
            label           = { Text("时", style = MaterialTheme.typography.labelSmall) },
            singleLine      = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape           = RoundedCornerShape(8.dp),
            modifier        = Modifier.width(52.dp),
            textStyle       = MaterialTheme.typography.bodySmall,
            colors          = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = FluentBlue,
                unfocusedBorderColor = FluentBorder
            )
        )

        // 分 输入框
        OutlinedTextField(
            value         = "%02d".format(m),
            onValueChange = { raw ->
                val newM = raw.filter { it.isDigit() }.toIntOrNull()?.coerceIn(0, 59) ?: m
                durMins  = h * 60 + newM
                push(durMins)
            },
            label           = { Text("分", style = MaterialTheme.typography.labelSmall) },
            singleLine      = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape           = RoundedCornerShape(8.dp),
            modifier        = Modifier.width(52.dp),
            textStyle       = MaterialTheme.typography.bodySmall,
            colors          = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = FluentBlue,
                unfocusedBorderColor = FluentBorder
            )
        )

        Spacer(Modifier.width(2.dp))

        // − 按钮（步长 10 分钟）
        FilledTonalIconButton(
            onClick  = { durMins = (durMins - 10).coerceAtLeast(10); push(durMins) },
            modifier = Modifier.size(32.dp),
            shape    = RoundedCornerShape(8.dp),
            colors   = IconButtonDefaults.filledTonalIconButtonColors(
                containerColor = FluentBorder,
                contentColor   = FluentMuted
            )
        ) {
            Icon(Icons.Default.Remove, contentDescription = "-10分钟", modifier = Modifier.size(16.dp))
        }

        // + 按钮（步长 10 分钟）
        FilledTonalIconButton(
            onClick  = { durMins = (durMins + 10).coerceAtMost(23 * 60); push(durMins) },
            modifier = Modifier.size(32.dp),
            shape    = RoundedCornerShape(8.dp),
            colors   = IconButtonDefaults.filledTonalIconButtonColors(
                containerColor = FluentBlueLight,
                contentColor   = FluentBlue
            )
        ) {
            Icon(Icons.Default.Add, contentDescription = "+10分钟", modifier = Modifier.size(16.dp))
        }

        // 结束时间提示
        Text(
            "→ ${addMinutesToTime(startTime.ifBlank { "08:00" }, durMins)}",
            style = MaterialTheme.typography.labelSmall,
            color = FluentMuted
        )
    }
}

/** InlineDurationPicker — AttendanceFormDialog 使用的别名，委托给 DurationChipsCompact。 */
@Composable
internal fun InlineDurationPicker(
    startTime: String,
    endTime: String,
    onEndChange: (String) -> Unit
) = DurationChipsCompact(startTime = startTime, endTime = endTime, onEndChange = onEndChange)'''

# ── Pattern: match DurationChipsCompact from its doc-comment (or @Composable) to just before
#             the next top-level @Composable / @OptIn / internal fun / private fun / fun
# We capture everything from the first doc comment or annotation before the function signature
# through the closing brace of that function body.

# Strategy: find the start marker and end marker using a brace-counting walk.

def replace_function(source, func_name, new_code):
    """Replace a @Composable function (and its preceding /** */ doc comment if any) in source."""

    # Find the line that contains "fun <func_name>("
    lines = source.split('\n')
    start_idx = None
    for i, line in enumerate(lines):
        if re.search(r'\bfun\s+' + re.escape(func_name) + r'\s*\(', line):
            start_idx = i
            break

    if start_idx is None:
        print(f"  WARNING: function {func_name} not found — skipping")
        return source

    # Walk backwards from start_idx to find the beginning of the block
    # (doc comment /** and annotations like @Composable, @OptIn, internal)
    block_start = start_idx
    for i in range(start_idx - 1, -1, -1):
        stripped = lines[i].strip()
        if (stripped.startswith('/**') or stripped.startswith('*') or stripped.startswith('*/')
                or stripped.startswith('@') or stripped in ('internal', 'private', 'public', '')
                or re.match(r'^(internal|private|public)?\s*(@\w+|/\*\*)', stripped)):
            block_start = i
        else:
            break

    # Walk forward from start_idx to find the closing brace of the function body
    # Count braces starting from the fun line
    brace_depth = 0
    found_open = False
    end_idx = start_idx
    for i in range(start_idx, len(lines)):
        for ch in lines[i]:
            if ch == '{':
                brace_depth += 1
                found_open = True
            elif ch == '}':
                brace_depth -= 1
        if found_open and brace_depth == 0:
            end_idx = i
            break

    # Reconstruct source with replacement
    before = '\n'.join(lines[:block_start])
    after  = '\n'.join(lines[end_idx + 1:])

    # Preserve a blank line before block if there was one
    if before and not before.endswith('\n\n'):
        before = before.rstrip('\n') + '\n'

    result = before + '\n' + new_code + '\n' + after
    print(f"  ✅ Replaced {func_name} (lines {block_start+1}–{end_idx+1})")
    return result

# Step 1: Replace DurationChipsCompact (which also includes InlineDurationPicker at end)
# First check if InlineDurationPicker already exists
has_inline = 'fun InlineDurationPicker(' in src

# Replace DurationChipsCompact
src = replace_function(src, 'DurationChipsCompact', NEW_DURATION_CHIPS)

# Step 2: If InlineDurationPicker already exists as a separate function, remove it
# (it's now included at the end of NEW_DURATION_CHIPS)
if has_inline:
    src = replace_function(src, 'InlineDurationPicker',
        '// InlineDurationPicker is now defined immediately after DurationChipsCompact above')

# Step 3: Ensure Icons.Default.Remove is imported
# Icons.Default.Add is already used elsewhere, Remove may not be
if 'Icons.Default.Remove' not in src:
    # The wildcard import "import androidx.compose.material.icons.filled.*" covers Remove
    # Just verify the wildcard is present
    if 'import androidx.compose.material.icons.filled.*' in src:
        print("  ✅ Icons.Default.Remove covered by filled.* wildcard import")
    else:
        print("  INFO: Please ensure Icons.Default.Remove is imported")

# Step 4: Ensure FilledTonalIconButton / IconButtonDefaults are available
# These come from androidx.compose.material3.* which is already imported via material3.*
if 'import androidx.compose.material3.*' in src:
    print("  ✅ FilledTonalIconButton covered by material3.* import")

with open(path, 'w', encoding='utf-8') as f:
    f.write(src)

print("=== Patch applied successfully ===")
PYEOF

echo "✅ apply.sh finished"
