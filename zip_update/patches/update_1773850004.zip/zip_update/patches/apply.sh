#!/usr/bin/env bash
set -e

SCHEDULE="app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt"
ATTENDANCE="app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt"

echo "=== Fixing ScheduleScreen.kt ==="

# Find the exact line numbers where the broken references appear
LINE_A=$(grep -n 'resolvedSubName\b' "$SCHEDULE" | grep -v 'resolvedSubName2' | head -1 | cut -d: -f1)
LINE_B=$(grep -n 'resolvedSubName2\b' "$SCHEDULE" | head -1 | cut -d: -f1)

echo "resolvedSubName  found at line: $LINE_A"
echo "resolvedSubName2 found at line: $LINE_B"

if [ -n "$LINE_A" ]; then
    # Line contains:  sub?.name ?: cl?.subject ?: "?",   OR   resolvedSubName,
    # In either case we want the calendar box Text to call resolvedSubjectName directly.
    # Inspect what's actually on that line:
    echo "Line $LINE_A content: $(sed -n "${LINE_A}p" "$SCHEDULE")"
    # Replace whatever is on that line with the correct call
    sed -i "${LINE_A}s/.*/                                            slot.resolvedSubjectName(state.subjects, state.classes),/" "$SCHEDULE"
    echo "✅ Fixed line $LINE_A (calendar box label)"
else
    echo "⚠️  resolvedSubName not found — checking for stale sub?.name fallback in calendar box..."
    # Try to find and fix the original pattern if neither patch touched it
    python3 - "$SCHEDULE" <<'INNER'
import sys
path = sys.argv[1]
text = open(path, encoding='utf-8').read()
old = 'sub?.name ?: cl?.subject ?: "?",'
new = 'slot.resolvedSubjectName(state.subjects, state.classes),'
if old in text:
    open(path, 'w', encoding='utf-8').write(text.replace(old, new))
    print("✅ Replaced sub?.name fallback in calendar box")
else:
    print("ℹ️  Pattern not found — already fixed or different")
INNER
fi

if [ -n "$LINE_B" ]; then
    echo "Line $LINE_B content: $(sed -n "${LINE_B}p" "$SCHEDULE")"
    # This is the list-view subjectName variable.
    # Replace with the correct call (same indentation as surrounding code)
    sed -i "${LINE_B}s/.*/                            val subjectName = slot.resolvedSubjectName(state.subjects, state.classes)/" "$SCHEDULE"
    echo "✅ Fixed line $LINE_B (list view subjectName)"
else
    echo "⚠️  resolvedSubName2 not found — checking for stale fallback in list view..."
    python3 - "$SCHEDULE" <<'INNER'
import sys
path = sys.argv[1]
text = open(path, encoding='utf-8').read()
old = 'val subjectName = sub?.name ?: cl?.subject?.takeIf { it.isNotBlank() } ?: "?"'
new = 'val subjectName = slot.resolvedSubjectName(state.subjects, state.classes)'
if old in text:
    open(path, 'w', encoding='utf-8').write(text.replace(old, new))
    print("✅ Replaced list-view stale fallback")
else:
    print("ℹ️  Pattern not found — already fixed or different")
INNER
fi

echo ""
echo "=== Fixing AttendanceScreen.kt ==="

# BUG-5: AttendanceCard title text — find and replace the stale fallback
python3 - "$ATTENDANCE" <<'INNER'
import sys
path = sys.argv[1]
text = open(path, encoding='utf-8').read()
changed = False

patterns = [
    # The exact string as it appears in AttendanceCard Row > Column > Text
    ('Text(sub?.name ?: cl?.subject ?: "?",',
     'Text(rec.resolvedSubjectName(vm.state.value.subjects, vm.state.value.classes),'),
]

for old, new in patterns:
    count = text.count(old)
    if count > 0:
        text = text.replace(old, new, 1)
        print(f"✅ Fixed AttendanceCard title ({count} occurrence replaced)")
        changed = True
    else:
        print(f"ℹ️  Pattern not found: {old[:60]}...")

if changed:
    open(path, 'w', encoding='utf-8').write(text)
    print("✅ AttendanceScreen.kt written")
else:
    print("ℹ️  AttendanceScreen.kt unchanged")
INNER

echo ""
echo "=== Verification ==="
echo "--- ScheduleScreen remaining broken refs ---"
grep -n 'resolvedSubName' "$SCHEDULE" || echo "(none)"
echo "--- AttendanceScreen check ---"
grep -n 'sub?.name ?: cl?.subject' "$ATTENDANCE" || echo "(none — good)"

echo ""
echo "✅ apply.sh completed"
