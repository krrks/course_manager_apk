#!/usr/bin/env bash
set -e

rm -f app/src/main/java/com/school/manager/data/KnowledgePointsData.kt
echo "Removed KnowledgePointsData.kt"

rm -f app/src/main/assets/knowledge_points.json
echo "Removed knowledge_points.json"
