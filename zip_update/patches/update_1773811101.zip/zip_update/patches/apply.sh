#!/usr/bin/env bash
set -e

# ── Fix 1: AttendanceScreen.kt — resolve subjectId via FK first ──────────────
# Old: val sId  = state.subjects.firstOrNull { it.name == cls.subject }?.id
#                 ?: initial?.subjectId ?: state.subjects.firstOrNull()?.id ?: 1L
# New: val sId  = cls.subjectId
#                 ?: state.subjects.firstOrNull { it.name == cls.subject }?.id
#                 ?: initial?.subjectId ?: state.subjects.firstOrNull()?.id ?: 1L

ATT="app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt"

# Use Python for reliable multi-line replacement
python3 - "$ATT" <<'PYEOF'
import sys, re

path = sys.argv[1]
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

old = (
    'val sId  = state.subjects.firstOrNull { it.name == cls.subject }?.id\n'
    '                   ?: initial?.subjectId ?: state.subjects.firstOrNull()?.id ?: 1L'
)
new = (
    'val sId  = cls.subjectId\n'
    '                   ?: state.subjects.firstOrNull { it.name == cls.subject }?.id\n'
    '                   ?: initial?.subjectId ?: state.subjects.firstOrNull()?.id ?: 1L'
)

if old not in content:
    print(f"WARNING: expected pattern not found in {path} — skipping AttendanceScreen fix")
else:
    content = content.replace(old, new)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ AttendanceScreen.kt: subjectId FK fix applied")
PYEOF

# ── Fix 2: ScheduleScreen.kt — resolve subjectId via FK in AddScheduleDialog & EditScheduleDialog ──
SCH="app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt"

python3 - "$SCH" <<'PYEOF'
import sys, re

path = sys.argv[1]
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# Both AddScheduleDialog and EditScheduleDialog contain the same pattern; replace all occurrences.
old = (
    'val sId = state.subjects.firstOrNull { it.name == cls.subject }?.id\n'
    '            ?: state.subjects.firstOrNull()?.id ?: return@FluentDialog'
)
new = (
    'val sId = cls.subjectId\n'
    '            ?: state.subjects.firstOrNull { it.name == cls.subject }?.id\n'
    '            ?: state.subjects.firstOrNull()?.id ?: return@FluentDialog'
)

count = content.count(old)
if count == 0:
    print(f"WARNING: expected pattern not found in {path} — skipping ScheduleScreen fix")
else:
    content = content.replace(old, new)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ ScheduleScreen.kt: subjectId FK fix applied ({count} occurrence(s))")
PYEOF

# ── Fix 3: AttendanceScreen.kt — subject badge display uses FK-resolved name ─
python3 - "$ATT" <<'PYEOF'
import sys

path = sys.argv[1]
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# The badge currently shows cls.subject (legacy string).
# Change to resolve via subjectId first so it stays in sync with Subject edits.
old = '        if (selectedClass?.subject?.isNotBlank() == true) {'
new = '        val resolvedSubjectName = selectedClass?.let { cls ->\n            state.subjects.find { it.id == cls.subjectId }?.name ?: cls.subject.ifBlank { null }\n        }\n        if (resolvedSubjectName?.isNotBlank() == true) {'

if old not in content:
    print(f"NOTE: badge pattern not found in {path} — may already be patched, skipping")
else:
    # Also replace the inner reference to selectedClass.subject
    content = content.replace(old, new)
    content = content.replace(
        '"科目：${selectedClass.subject}"',
        '"科目：$resolvedSubjectName"'
    )
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ AttendanceScreen.kt: subject badge FK fix applied")
PYEOF

# ── Fix 4: ScheduleScreen.kt — subject badge in AddScheduleDialog uses FK ────
python3 - "$SCH" <<'PYEOF'
import sys

path = sys.argv[1]
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# AddScheduleDialog reads classSubject from cls.subject string.
# Change to resolve via subjectId first.
old = '    val classSubject = state.classes.firstOrNull { it.name == className }?.subject ?: ""'
new = (
    '    val _selClass = state.classes.firstOrNull { it.name == className }\n'
    '    val classSubject = _selClass?.let { cls ->\n'
    '        state.subjects.find { it.id == cls.subjectId }?.name ?: cls.subject.ifBlank { null }\n'
    '    } ?: ""'
)

if old not in content:
    print(f"NOTE: classSubject pattern not found in {path} — may already be patched, skipping")
else:
    content = content.replace(old, new)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ ScheduleScreen.kt: classSubject FK fix applied")
PYEOF

echo "✅ All patches applied successfully"
