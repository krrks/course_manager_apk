#!/usr/bin/env bash
set -e

echo "── Removing old screen files replaced by LessonScreen ──"

rm -f app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt
echo "  ✅ Removed ScheduleScreen.kt"

rm -f app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt
echo "  ✅ Removed AttendanceScreen.kt"

rm -f AttendanceScreen_FormDialog_PATCH.kt
echo "  ✅ Removed AttendanceScreen_FormDialog_PATCH.kt (root)"

echo "── apply.sh completed ──"
