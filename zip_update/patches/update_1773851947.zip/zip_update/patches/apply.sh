#!/usr/bin/env bash
set -e

SCREENS="app/src/main/java/com/school/manager/ui/screens"

echo "=== Plan A patch: remove subjectId from Schedule/Attendance ==="

# ─── ScheduleScreen.kt ────────────────────────────────────────────────────────

SCH="$SCREENS/ScheduleScreen.kt"

# 1. AddScheduleDialog: classSubject now comes purely from subjectId FK
sed -i 's|val classSubject = _selClass?.let { cls ->\n.*state\.subjects\.find.*\n.*} ?: ""|val classSubject = _selClass?.resolvedSubject(state.subjects)?.name ?: ""|g' "$SCH" || true

# 2. Remove the sId / subjectId resolution in AddScheduleDialog onConfirm
#    old: val sId = cls.subjectId ?: ... ; vm.addSchedule(cls.id, sId, ...)
#    new: vm.addSchedule(cls.id, teacherId=tId, ...)
python3 - "$SCH" <<'PYEOF'
import re, sys
path = sys.argv[1]
text = open(path).read()

# Fix AddScheduleDialog classSubject resolution
text = re.sub(
    r'val classSubject = _selClass\?\.let \{ cls ->[^}]+\} \?\? ""',
    'val classSubject = _selClass?.resolvedSubject(state.subjects)?.name ?: ""',
    text, flags=re.DOTALL
)

# Fix AddScheduleDialog onConfirm: remove sId and pass without subjectId
text = re.sub(
    r'val sId = cls\.subjectId\s*\?\:\s*state\.subjects\.firstOrNull.*?\?\: .*?\n\s*val tId.*?\n\s*vm\.addSchedule\(cls\.id, sId, tId',
    lambda m: re.sub(
        r'val sId[^\n]+\n',
        '',
        m.group(0)
    ).replace('vm.addSchedule(cls.id, sId, tId', 'val tId = state.teachers.firstOrNull { it.name == teacherName }?.id\n        vm.addSchedule(cls.id, teacherId = tId'),
    text, flags=re.DOTALL
)

# Fix EditScheduleDialog onConfirm same pattern
text = re.sub(
    r'(FluentDialog\(title = "编辑课程".*?onConfirm = \{[^}]*?)val sId = cls\.subjectId[^\n]+\n([^\n]*vm\.updateSchedule)',
    lambda m: m.group(1) + m.group(2),
    text, flags=re.DOTALL
)

# Fix slot.subjectId references for color resolution
# old: state.subjects.indexOfFirst { it.id == slot.subjectId }
# new: state.subjects.indexOfFirst { it.id == state.classes.find { c -> c.id == slot.classId }?.subjectId }
text = text.replace(
    'state.subjects.indexOfFirst { it.id == slot.subjectId }',
    'state.subjects.indexOfFirst { it.id == state.classes.find { c -> c.id == slot.classId }?.subjectId }'
)

# Fix state.subjects.find { it.id == slot.subjectId } (for color in bitmap export)
text = text.replace(
    'state.subjects.indexOfFirst { it.id == slot.subjectId }',
    'state.subjects.indexOfFirst { it.id == state.classes.find { c -> c.id == slot.classId }?.subjectId }'
)

# Fix resolvedSubjectName calls in ScheduleScreen
text = text.replace(
    'slot.resolvedSubjectName(state.subjects, state.classes)',
    'slot.subjectName(state.classes, state.subjects)'
)

# Fix sub = state.subjects.find { it.id == slot.subjectId } pattern for color
text = re.sub(
    r'val sub\s*=\s*state\.subjects\.find \{ it\.id == slot\.subjectId \}',
    'val sub = state.classes.find { it.id == slot.classId }?.resolvedSubject(state.subjects)',
    text
)
# also: state.subjects.find { s -> state.classes.find { it.id == slot.classId }?.subject == s.name }
text = re.sub(
    r'state\.subjects\.find \{ s -> state\.classes\.find \{ it\.id == slot\.classId \}\?\.subject == s\.name \}',
    'state.classes.find { it.id == slot.classId }?.resolvedSubject(state.subjects)',
    text
)

# Fix subjectName in AddAttendanceFromSlotDialog
text = text.replace(
    'val subjectName = state.subjects.find { it.id == slot.subjectId }?.name\n        ?: state.classes.find { it.id == slot.classId }?.subject ?: ""',
    'val subjectName = state.classes.find { it.id == slot.classId }?.resolvedSubject(state.subjects)?.name ?: ""'
)

# Fix Attendance creation in AddAttendanceFromSlotDialog (remove subjectId = slot.subjectId)
text = re.sub(
    r'onSave\(Attendance\(\s*id\s*=.*?classId\s*=\s*cls\.id,\s*subjectId\s*=\s*slot\.subjectId,',
    lambda m: m.group(0).replace('subjectId = slot.subjectId,', ''),
    text, flags=re.DOTALL
)

# Fix bitmap export: state.subjects.find { it.id == slot.subjectId }?.name
text = text.replace(
    'state.subjects.find { it.id == slot.subjectId }?.name',
    'state.classes.find { it.id == slot.classId }?.resolvedSubject(state.subjects)?.name'
)
text = text.replace(
    '?: state.classes.find { it.id == slot.classId }?.subject ?: "?"',
    '?: "?"'
)

# Fix cls.subject references for subjectId in AddScheduleDialog
text = re.sub(
    r'val classSubject = _selClass\?\.let \{ cls ->.*?\} \?\? ""',
    'val classSubject = _selClass?.resolvedSubject(state.subjects)?.name ?: ""',
    text, flags=re.DOTALL
)

open(path, 'w').write(text)
print("ScheduleScreen.kt patched")
PYEOF

# ─── AttendanceScreen.kt ──────────────────────────────────────────────────────

ATT="$SCREENS/AttendanceScreen.kt"

python3 - "$ATT" <<'PYEOF'
import re, sys
path = sys.argv[1]
text = open(path).read()

# resolvedSubjectName → subjectName
text = text.replace(
    'rec.resolvedSubjectName(vm.state.value.subjects, vm.state.value.classes)',
    'rec.subjectName(vm.state.value.classes, vm.state.value.subjects)'
)
text = text.replace(
    'rec.resolvedSubjectName(state.subjects, state.classes)',
    'rec.subjectName(state.classes, state.subjects)'
)

# val sub = vm.subject(rec.subjectId)  → derive from class
text = re.sub(
    r'val sub\s*=\s*vm\.subject\(rec\.subjectId\)',
    'val sub = vm.schoolClass(rec.classId)?.resolvedSubject(state.subjects)',
    text
)

# lessonCount: it.subjectId == rec.subjectId → derive via class
text = re.sub(
    r'it\.subjectId == rec\.subjectId && it\.classId == rec\.classId',
    'it.classId == rec.classId',
    text
)

# DetailRow("科目", sub?.name ?: classSubject ?: "─")
# remove classSubject local val if present
text = re.sub(
    r'\s*val classSubject = cl\?\.subject.*?\n',
    '\n',
    text
)
text = text.replace(
    'sub?.name ?: classSubject ?: "─"',
    'sub?.name ?: "─"'
)

# AttendanceFormDialog onConfirm: remove subjectId resolution
# old: val sId = cls.subjectId ?: ... 
text = re.sub(
    r'val sId\s*=\s*cls\.subjectId[^\n]+\n',
    '',
    text
)
# old: onSave(Attendance(newId, cls.id, sId, tId, ...))
text = re.sub(
    r'onSave\(Attendance\(newId, cls\.id, sId, tId,',
    'onSave(Attendance(newId, cls.id, tId,',
    text
)

# Color resolution: sub based on subjectId → class subjectId
text = re.sub(
    r'val sub\s*=\s*state\.subjects\.find \{ it\.id == rec\.subjectId \}',
    'val sub = state.classes.find { it.id == rec.classId }?.resolvedSubject(state.subjects)',
    text
)
text = re.sub(
    r'state\.subjects\.find \{ it\.id == rec\.subjectId \}',
    'state.classes.find { it.id == rec.classId }?.resolvedSubject(state.subjects)',
    text
)

# resolvedSubjectName in badge inside AttendanceFormDialog
text = re.sub(
    r'val resolvedSubjectName = selectedClass\?\.let \{ cls ->\s*state\.subjects\.find \{ it\.id == cls\.subjectId \}\?\.name.*?\} \?\? ""',
    'val resolvedSubjectName = selectedClass?.resolvedSubject(state.subjects)?.name ?: ""',
    text, flags=re.DOTALL
)

open(path, 'w').write(text)
print("AttendanceScreen.kt patched")
PYEOF

# ─── ClassesScreen.kt ─────────────────────────────────────────────────────────

CLS="$SCREENS/ClassesScreen.kt"

python3 - "$CLS" <<'PYEOF'
import re, sys
path = sys.argv[1]
text = open(path).read()

# ClassDetailDialog: remove subject string display
# old: val subjectDisplay = state.subjects.find{...}?.name ?: cls.subject.ifBlank { null }
text = re.sub(
    r'val subjectDisplay = state\.subjects\.find.*?\.ifBlank \{ null \}',
    'val subjectDisplay = cls.resolvedSubject(state.subjects)?.name',
    text, flags=re.DOTALL
)

# ClassFormDialog: remove selectedSubjectName legacy fallback via subject string
# old: ?: state.subjects.find { it.name == cls.subject }
text = re.sub(
    r'\?: state\.subjects\.find \{ it\.name == cls\.subject \}',
    '',
    text
)

# ClassFormDialog onSave: remove subject= parameter
text = re.sub(
    r'onSave\(SchoolClass\(.*?subjectId\s*=\s*selectedSubjectId,\s*subject\s*=\s*selectedSubjectName.*?\)\)',
    lambda m: re.sub(r',\s*subject\s*=\s*\S+', '', m.group(0)),
    text, flags=re.DOTALL
)

# vm.addSchoolClass / vm.updateSchoolClass: remove subject= arg
text = re.sub(r',\s*subject\s*=\s*selectedSubjectName', '', text)

# SchoolClass constructor calls with subject string positional arg
# SchoolClass(id, name, grade, count, htId, subjectId, subjectName, code)
# → SchoolClass(id, name, grade, count, htId, subjectId, code)
text = re.sub(
    r'SchoolClass\(([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*subjectId\s*=\s*([^,]+),\s*subject\s*=\s*[^,]+,\s*code\s*=\s*([^)]+)\)',
    r'SchoolClass(\1, \2, \3, \4, \5, subjectId = \6, code = \7)',
    text
)

open(path, 'w').write(text)
print("ClassesScreen.kt patched")
PYEOF

# ─── SubjectsScreen.kt ────────────────────────────────────────────────────────

SUB="$SCREENS/SubjectsScreen.kt"

python3 - "$SUB" <<'PYEOF'
import re, sys
path = sys.argv[1]
text = open(path).read()

# SubjectStatChip: schedCount uses schedule.count { it.subjectId == s.id }
# → needs to go through classes now
text = re.sub(
    r'val schedCount = state\.schedule\.count\s*\{ it\.subjectId == s\.id \}',
    'val schedCount = state.schedule.count { slot -> state.classes.find { it.id == slot.classId }?.subjectId == s.id }',
    text
)
text = re.sub(
    r'val attCount = state\.attendance\.count\s*\{ it\.subjectId == s\.id \}',
    'val attCount = state.attendance.count { att -> state.classes.find { it.id == att.classId }?.subjectId == s.id }',
    text
)

# SubjectDetailDialog: same counts
text = re.sub(
    r'state\.schedule\.count\s*\{ it\.subjectId == s\.id \}',
    'state.schedule.count { slot -> state.classes.find { it.id == slot.classId }?.subjectId == s.id }',
    text
)
text = re.sub(
    r'state\.attendance\.count\s*\{ it\.subjectId == s\.id \}',
    'state.attendance.count { att -> state.classes.find { it.id == att.classId }?.subjectId == s.id }',
    text
)

open(path, 'w').write(text)
print("SubjectsScreen.kt patched")
PYEOF

# ─── StatsScreen.kt ───────────────────────────────────────────────────────────
# StatsScreen uses only attendance.classId / teacherId — no subjectId references.
# No changes needed.
echo "StatsScreen.kt — no subjectId references, skipped"

echo "=== All patches applied successfully ==="
