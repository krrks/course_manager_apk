#!/usr/bin/env bash
set -e

SCHEDULE="app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt"
ATTENDANCE="app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt"

# ─── BUG-4 FIX: ScheduleScreen ────────────────────────────────────────────────
# Replace stale sub?.name ?: cl?.subject fallback with resolvedSubjectName()
# in BOTH the calendar view box label AND the list view subjectName variable.

python3 << 'PYEOF'
import sys

path = "app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt"
text = open(path, encoding='utf-8').read()
original = text

# ── Fix A: calendar view slot box — look up sub then derive label ──────────────
# The calendar view has two nearly-identical blocks (day columns + time axis).
# Both use:  sub?.name ?: cl?.subject ?: "?"
# We replace the calendar-box Text call with resolvedSubjectName().
# The pattern is unique enough: it's inside a Column(Modifier.padding(4.dp)) block.

old_a = '                                        Text(\n                                            sub?.name ?: cl?.subject ?: "?",\n                                            style      = MaterialTheme.typography.labelSmall,\n                                            color      = subColor,\n                                            fontWeight = FontWeight.Bold,\n                                            maxLines   = 1,\n                                            overflow   = TextOverflow.Ellipsis\n                                        )'
new_a = '                                        Text(\n                                            slot.resolvedSubjectName(state.subjects, state.classes),\n                                            style      = MaterialTheme.typography.labelSmall,\n                                            color      = subColor,\n                                            fontWeight = FontWeight.Bold,\n                                            maxLines   = 1,\n                                            overflow   = TextOverflow.Ellipsis\n                                        )'

count_a = text.count(old_a)
if count_a > 0:
    text = text.replace(old_a, new_a)
    print(f'✅ Fix A applied ({count_a} occurrence(s)) — calendar box label')
else:
    print('⚠️  Fix A: pattern not found, trying relaxed match...')
    # Relaxed: just replace the literal string in context
    old_a2 = 'sub?.name ?: cl?.subject ?: "?",'
    if old_a2 in text:
        text = text.replace(old_a2, 'slot.resolvedSubjectName(state.subjects, state.classes),')
        print('✅ Fix A (relaxed) applied')
    else:
        print('⚠️  Fix A relaxed also not found — may already be fixed')

# ── Fix B: list view subjectName variable ─────────────────────────────────────
old_b = '                            val subjectName = sub?.name ?: cl?.subject?.takeIf { it.isNotBlank() } ?: "?"'
new_b = '                            // BUG-4 FIX: use resolvedSubjectName to avoid stale cls.subject fallback\n                            val subjectName = slot.resolvedSubjectName(state.subjects, state.classes)'

if old_b in text:
    text = text.replace(old_b, new_b)
    print('✅ Fix B applied — list view subjectName')
else:
    print('⚠️  Fix B: pattern not found — may already be fixed')

if text != original:
    open(path, 'w', encoding='utf-8').write(text)
    print(f'✅ ScheduleScreen.kt written')
else:
    print('ℹ️  ScheduleScreen.kt unchanged')
PYEOF

# ─── BUG-5 FIX: AttendanceScreen ──────────────────────────────────────────────
# AttendanceCard currently shows:  sub?.name ?: cl?.subject ?: "?"
# Replace with rec.resolvedSubjectName() which is now defined on Attendance in Models.kt.
# The pattern appears in the AttendanceCard composable body.

python3 << 'PYEOF'
path = "app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt"
text = open(path, encoding='utf-8').read()
original = text

# The AttendanceCard body has:
#   Text(sub?.name ?: cl?.subject ?: "?",
#        style = MaterialTheme.typography.titleMedium, ...)
# We target specifically the one inside the Card's Row > Column.

old = '                    Text(sub?.name ?: cl?.subject ?: "?",'
new = '                    // BUG-5 FIX: use resolvedSubjectName (Attendance extension in Models.kt)\n                    Text(rec.resolvedSubjectName(vm.state.value.subjects, vm.state.value.classes),'

count = text.count(old)
if count > 0:
    text = text.replace(old, new, 1)  # only first occurrence = the card title
    print(f'✅ BUG-5 Fix applied (AttendanceCard title text)')
else:
    print('⚠️  BUG-5 pattern not found — may already be fixed')

# Also fix the week/day calendar view label: sub?.name ?: cl?.subject ?: "?"
# These appear in DayView / WeekView calendar event boxes
old2 = '                                        Text(sub?.name ?: cl?.subject ?: "?",'
new2 = '                                        Text(rec.resolvedSubjectName(vm.state.value.subjects, vm.state.value.classes),'
if old2 in text:
    text = text.replace(old2, new2)
    print('✅ BUG-5 calendar view label fix applied')

old3 = '                                            Text(sub?.name ?: cl?.subject ?: "?",'
new3 = '                                            Text(rec.resolvedSubjectName(vm.state.value.subjects, vm.state.value.classes),'
if old3 in text:
    text = text.replace(old3, new3)
    print('✅ BUG-5 calendar view label (indented) fix applied')

if text != original:
    open(path, 'w', encoding='utf-8').write(text)
    print(f'✅ AttendanceScreen.kt written')
else:
    print('ℹ️  AttendanceScreen.kt unchanged')
PYEOF

echo "✅ apply.sh completed"
