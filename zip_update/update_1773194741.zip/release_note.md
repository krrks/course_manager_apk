# 🛠️ Bug Fix: Compilation Errors

## Changes in this patch

### `app/src/main/java/com/school/manager/viewmodel/AppViewModel.kt`

Fixed 3 type/signature mismatches caused by `Teacher` and `SchoolClass` model updates not being reflected in the ViewModel:

| Error | Fix |
|-------|-----|
| `addTeacher(name, subject, phone, avatarUri)` — old 4-arg signature | Updated to `addTeacher(name, gender, phone, subjectIds, avatarUri, code)` matching `Teacher` data class |
| `Teacher(…, String?, List<Long>)` arg order wrong | Constructor call now matches `Teacher(id, name, gender, phone, subjectIds, avatarUri, code)` |
| `addSchoolClass(name, grade, subject, headTeacherId)` — missing `count` | Updated to `addSchoolClass(name, grade, count, headTeacherId, subject, code)` matching `SchoolClass` data class |

### `app/src/main/java/com/school/manager/ui/screens/ClassesScreen.kt`

Fixed 3 unresolved reference errors — old method names no longer existed on `AppViewModel`:

| Error | Fix |
|-------|-----|
| `vm.deleteClass(…)` | → `vm.deleteSchoolClass(…)` |
| `vm.updateClass(…)` | → `vm.updateSchoolClass(…)` |
| `vm.addClass(…)` | → `vm.addSchoolClass(…)` |
