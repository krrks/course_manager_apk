#!/usr/bin/env bash
set -e

SCHEDULE="app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt"
ATTENDANCE="app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  PATCH: 优化「添加上课记录」Dialog UI"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Step 1: ScheduleScreen.kt — StartTimeCompact: private → internal ──
sed -i 's/^private fun StartTimeCompact(/internal fun StartTimeCompact(/' "$SCHEDULE"
echo "✅ StartTimeCompact → internal"

# ── Step 2: ScheduleScreen.kt — DurationChipsCompact: private → internal ──
sed -i 's/^private fun DurationChipsCompact(/internal fun DurationChipsCompact(/' "$SCHEDULE"
echo "✅ DurationChipsCompact → internal"

# ── Step 3: ScheduleScreen.kt — Replace AddAttendanceFromScheduleDialog ──
python3 - <<'PYEOF'
import re, pathlib

path = pathlib.Path("app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt")
src  = path.read_text(encoding="utf-8")

# Locate the function — find start marker
start_marker = "@Composable\nprivate fun AddAttendanceFromScheduleDialog("
# Find its closing brace by counting braces
start_idx = src.index(start_marker)
# Walk forward to find the matching closing brace
depth = 0
i = start_idx
found_first_open = False
end_idx = -1
while i < len(src):
    c = src[i]
    if c == '{':
        depth += 1
        found_first_open = True
    elif c == '}':
        depth -= 1
        if found_first_open and depth == 0:
            end_idx = i + 1
            break
    i += 1

assert end_idx != -1, "Could not find end of AddAttendanceFromScheduleDialog"

new_func = '''@Composable
private fun AddAttendanceFromScheduleDialog(
    slot: Schedule, state: AppState, vm: AppViewModel,
    onDismiss: () -> Unit, onSave: (Attendance) -> Unit
) {
    val today       = LocalDate.now()
    var date        by remember { mutableStateOf(today.toString()) }
    var teacherName by remember { mutableStateOf(state.teachers.find { it.id == slot.teacherId }?.name ?: "") }
    var startTime   by remember { mutableStateOf(slot.resolvedStart()) }
    var endTime     by remember { mutableStateOf(slot.resolvedEnd()) }
    var topic       by remember { mutableStateOf("") }
    var status      by remember { mutableStateOf("completed") }
    var notes       by remember { mutableStateOf("") }
    var code        by remember { mutableStateOf(genCode("ATT")) }

    val subjectName = state.subjects.find { it.id == slot.subjectId }?.name
        ?: state.classes.find { it.id == slot.classId }?.subject ?: ""
    val allStudents = state.students.filter { s ->
        state.classes.find { it.id == slot.classId }?.let { s.classIds.contains(it.id) } == true
    }
    val checkedIds = remember { mutableStateListOf<Long>().also { it.addAll(allStudents.map { s -> s.id }) } }

    FluentDialog(title = "添加上课记录", onDismiss = onDismiss, onConfirm = {
        val tId = state.teachers.firstOrNull { it.name == teacherName }?.id ?: slot.teacherId
        val cls = state.classes.find { it.id == slot.classId } ?: return@FluentDialog
        onSave(Attendance(
            id        = System.currentTimeMillis(),
            classId   = cls.id,
            subjectId = slot.subjectId,
            teacherId = tId,
            date      = date,
            startTime = startTime,
            endTime   = endTime,
            topic     = topic,
            status    = status,
            notes     = notes,
            attendees = checkedIds.toList(),
            code      = code.trim().ifBlank { genCode("ATT") }
        ))
    }) {
        // ── 行1：编号½ + 状态½ ────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(1f)) {
                FormTextField("编号", code, { code = it }, "自动生成")
            }
            Box(Modifier.weight(1f)) {
                FormDropdown("状态", status, listOf("completed", "cancelled", "pending")) { status = it }
            }
        }

        // ── 行2：科目 badge½ + 教师½ ─────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (subjectName.isNotBlank()) {
                Surface(
                    shape    = RoundedCornerShape(12.dp),
                    color    = FluentBlueLight,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        "📚 $subjectName",
                        style      = MaterialTheme.typography.bodyMedium,
                        color      = FluentBlue,
                        fontWeight = FontWeight.SemiBold,
                        modifier   = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                        maxLines   = 1
                    )
                }
            } else {
                Spacer(Modifier.weight(1f))
            }
            Box(Modifier.weight(1f)) {
                FormDropdown("教师", teacherName, listOf("") + state.teachers.map { it.name }) { teacherName = it }
            }
        }

        // ── 行3：日期½ + 开始时间½ ────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(1f)) {
                DatePickerField("日期", date) { date = it }
            }
            Box(Modifier.weight(1f)) {
                StartTimeCompact(startTime) { newStart ->
                    val dur = minutesBetween(startTime, endTime).coerceAtLeast(30)
                    startTime = newStart
                    endTime   = addMinutesToTime(newStart, dur)
                }
            }
        }

        // ── 行4：课题⅔ + 时长⅓ ───────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(2f)) {
                FormTextField("课题", topic, { topic = it }, "本节课主题")
            }
            Box(Modifier.weight(1f)) {
                DurationChipsCompact(startTime = startTime, endTime = endTime) { endTime = it }
            }
        }

        // ── 出勤学生 ─────────────────────────────────────────────────
        if (allStudents.isNotEmpty()) {
            SectionHeader("出勤学生")
            androidx.compose.foundation.layout.FlowRow(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                allStudents.forEach { s ->
                    val on = checkedIds.contains(s.id)
                    FilterChip(selected = on, onClick = {
                        if (on) checkedIds.remove(s.id) else checkedIds.add(s.id)
                    }, label = { Text(s.name) })
                }
            }
        }

        // ── 备注 ─────────────────────────────────────────────────────
        FormTextField("备注", notes, { notes = it }, "可选")
    }
}'''

result = src[:start_idx] + new_func + src[end_idx:]
path.write_text(result, encoding="utf-8")
print("✅ AddAttendanceFromScheduleDialog replaced")
PYEOF

echo "✅ Step 3 complete"

# ── Step 4: AttendanceScreen.kt — Replace AttendanceFormDialog ──
python3 - <<'PYEOF'
import re, pathlib

path = pathlib.Path("app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt")
src  = path.read_text(encoding="utf-8")

# Find the LAST occurrence of "internal fun AttendanceFormDialog" (the form one, not the detail)
# It's marked as "internal fun AttendanceFormDialog"
marker = "@Composable\ninternal fun AttendanceFormDialog("
# Find all occurrences
positions = [m.start() for m in re.finditer(re.escape(marker), src)]
assert len(positions) > 0, "AttendanceFormDialog not found"

# Use the last occurrence (the form dialog, not the detail one calling it)
start_idx = positions[-1]

depth = 0
i = start_idx
found_first_open = False
end_idx = -1
while i < len(src):
    c = src[i]
    if c == '{':
        depth += 1
        found_first_open = True
    elif c == '}':
        depth -= 1
        if found_first_open and depth == 0:
            end_idx = i + 1
            break
    i += 1

assert end_idx != -1, "Could not find end of AttendanceFormDialog"

new_func = '''@Composable
internal fun AttendanceFormDialog(
    title: String, initial: Attendance?,
    state: AppState, vm: AppViewModel,
    onDismiss: () -> Unit, onSave: (Attendance) -> Unit
) {
    var className   by remember { mutableStateOf(state.classes.firstOrNull { it.id == initial?.classId }?.name ?: "") }
    var teacherName by remember { mutableStateOf(state.teachers.firstOrNull { it.id == initial?.teacherId }?.name ?: "") }
    var date        by remember { mutableStateOf(initial?.date ?: LocalDate.now().toString()) }
    var startTime   by remember { mutableStateOf(initial?.resolvedStart() ?: "08:00") }
    var endTime     by remember { mutableStateOf(initial?.resolvedEnd()   ?: "08:45") }
    var topic       by remember { mutableStateOf(initial?.topic  ?: "") }
    var status      by remember { mutableStateOf(initial?.status ?: "completed") }
    var notes       by remember { mutableStateOf(initial?.notes  ?: "") }
    var attendees   by remember { mutableStateOf<List<Long>>(initial?.attendees ?: emptyList()) }
    var code        by remember { mutableStateOf(initial?.code?.ifBlank { null } ?: genCode("ATT")) }

    val selectedClass  = state.classes.firstOrNull { it.name == className }
    val classStudents  = state.students.filter { s -> s.classIds.contains(selectedClass?.id) }

    FluentDialog(title = title, onDismiss = onDismiss, onConfirm = {
        val cls  = state.classes.firstOrNull { it.name == className } ?: return@FluentDialog
        val sId  = state.subjects.firstOrNull { it.name == cls.subject }?.id
                   ?: initial?.subjectId ?: state.subjects.firstOrNull()?.id ?: 1L
        val tId  = state.teachers.firstOrNull { it.name == teacherName }?.id
        val newId = if (initial != null && initial.id != 0L) initial.id else System.currentTimeMillis()
        onSave(Attendance(newId, cls.id, sId, tId, date, 0, startTime, endTime,
                          topic, status, notes, attendees, code.trim().ifBlank { genCode("ATT") }))
    }) {
        // ── 行1：编号½ + 状态½ ────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(1f)) {
                FormTextField("编号", code, { code = it }, "自动生成")
            }
            Box(Modifier.weight(1f)) {
                FormDropdown("状态", status, listOf("completed", "cancelled", "pending")) { status = it }
            }
        }

        // ── 行2：班级½ + 教师½ ────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(1f)) {
                FormDropdown("班级", className, state.classes.map { it.name }) {
                    className = it; attendees = emptyList()
                }
            }
            Box(Modifier.weight(1f)) {
                FormDropdown("教师", teacherName, listOf("") + state.teachers.map { it.name }) { teacherName = it }
            }
        }

        // ── 科目 badge ────────────────────────────────────────────────
        if (selectedClass?.subject?.isNotBlank() == true) {
            Surface(shape = RoundedCornerShape(8.dp), color = FluentPurple.copy(alpha = 0.1f)) {
                Text(
                    "科目：${selectedClass.subject}",
                    style      = MaterialTheme.typography.bodySmall,
                    color      = FluentPurple,
                    fontWeight = FontWeight.SemiBold,
                    modifier   = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        // ── 行3：日期½ + 开始时间½ ────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(1f)) {
                DatePickerField("日期", date) { date = it }
            }
            Box(Modifier.weight(1f)) {
                StartTimeCompact(startTime) { newStart ->
                    val dur = minutesBetween(startTime, endTime).coerceAtLeast(30)
                    startTime = newStart
                    endTime   = addMinutesToTime(newStart, dur)
                }
            }
        }

        // ── 行4：课题⅔ + 时长⅓ ───────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(2f)) {
                FormTextField("课题", topic, { topic = it }, "本节课主题")
            }
            Box(Modifier.weight(1f)) {
                DurationChipsCompact(startTime = startTime, endTime = endTime) { endTime = it }
            }
        }

        // ── 出勤学生 ─────────────────────────────────────────────────
        if (classStudents.isNotEmpty()) {
            SectionHeader("出勤学生")
            androidx.compose.foundation.layout.FlowRow(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                classStudents.forEach { s ->
                    val on = attendees.contains(s.id)
                    FilterChip(selected = on, onClick = {
                        attendees = if (on) attendees.filter { it != s.id } else attendees + s.id
                    }, label = { Text(s.name) })
                }
            }
        }

        // ── 备注 ─────────────────────────────────────────────────────
        FormTextField("备注", notes, { notes = it }, "可选")
    }
}'''

result = src[:start_idx] + new_func + src[end_idx:]
path.write_text(result, encoding="utf-8")
print("✅ AttendanceFormDialog replaced")
PYEOF

echo "✅ Step 4 complete"

# ── Step 5: AttendanceScreen.kt — add cross-file references ──
# Since StartTimeCompact and DurationChipsCompact are now internal in ScheduleScreen.kt,
# and both files are in the same package (com.school.manager.ui.screens),
# no explicit import is needed — internal visibility is package-scoped within the module.
echo "✅ Step 5: No import changes needed (same package, internal visibility)"

# ── Step 6: AttendanceScreen.kt — add minutesBetween + addMinutesToTime helpers ──
# These private helpers exist in ScheduleScreen.kt but AttendanceFormDialog
# now calls them directly (same package). We need to check if they're already
# present in AttendanceScreen.kt; if not, we add them.
python3 - <<'PYEOF'
import pathlib

path = pathlib.Path("app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt")
src  = path.read_text(encoding="utf-8")

helpers_needed = "private fun minutesBetween" not in src or "private fun addMinutesToTime" not in src

if helpers_needed:
    # These helpers are private in ScheduleScreen.kt, so we add internal copies here
    helper_block = """
// ── Time helpers (mirrors of ScheduleScreen private helpers) ─────────────────
private fun addMinutesToTime(hhmm: String, minutes: Int): String {
    val base  = if (hhmm.isBlank()) 8 * 60 else timeToMinutes(hhmm)
    val total = (base + minutes).coerceIn(0, 23 * 60 + 59)
    return "%02d:%02d".format(total / 60, total % 60)
}

private fun minutesBetween(start: String, end: String): Int =
    if (start.isBlank() || end.isBlank()) 60
    else (timeToMinutes(end) - timeToMinutes(start)).coerceAtLeast(0)

"""
    # Insert before the first @Composable fun in the file
    import_idx = src.index("@Composable")
    result = src[:import_idx] + helper_block + src[import_idx:]
    path.write_text(result, encoding="utf-8")
    print("✅ Added minutesBetween + addMinutesToTime helpers to AttendanceScreen.kt")
else:
    print("✅ Helpers already present in AttendanceScreen.kt, skipping")
PYEOF

echo "✅ All steps complete!"
echo ""
echo "📋 Modified files:"
echo "   - ScheduleScreen.kt  (StartTimeCompact/DurationChipsCompact → internal,"
echo "                         AddAttendanceFromScheduleDialog rewritten)"
echo "   - AttendanceScreen.kt (AttendanceFormDialog rewritten with compact row layout)"
