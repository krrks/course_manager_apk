#!/usr/bin/env bash
# ============================================================
#  pack_changes.sh
#  将相对于 HEAD（或上一次提交）修改过的源文件打包成一个 zip，
#  放入 zip_update/ 目录。
#
#  用法：
#    chmod +x pack_changes.sh
#    ./pack_changes.sh           # 打包当前工作区的所有改动
#    ./pack_changes.sh HEAD~3    # 打包相对某个基准 commit 的改动
#
#  打包产物结构：
#    zip_update/update_YYYYMMDD_HHMMSS.zip
#      └── app/src/...          ← 直接对应项目根目录
#
#  build.yml 中的 "Extract zip to repo root" 步骤会将此 zip 解压并
#  覆盖到仓库根目录，然后自动编译生成 APK。
# ============================================================
set -euo pipefail

BASE_REF="${1:-HEAD}"           # 基准 commit，默认 HEAD（工作区 vs HEAD）
ZIP_DIR="zip_update"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
ZIP_NAME="${ZIP_DIR}/update_${TIMESTAMP}.zip"

mkdir -p "$ZIP_DIR"

# ── 1. 收集改动的文件 ──────────────────────────────────────────────────────────
if [ "$BASE_REF" = "HEAD" ]; then
    # 工作区改动（已暂存 + 未暂存）+ 未跟踪文件
    CHANGED=$(
        git diff --name-only HEAD 2>/dev/null
        git ls-files --others --exclude-standard 2>/dev/null
    )
    # 如果工作区干净，回退到与上一提交的差异
    if [ -z "$CHANGED" ]; then
        echo "ℹ️  工作区无改动，改为比对 HEAD~1 → HEAD …"
        CHANGED=$(git diff --name-only HEAD~1 HEAD 2>/dev/null || true)
    fi
else
    CHANGED=$(git diff --name-only "$BASE_REF" HEAD 2>/dev/null || true)
fi

# ── 2. 排除不应打包的路径 ──────────────────────────────────────────────────────
FILTERED=$(echo "$CHANGED" \
    | grep -v '^\.github/' \
    | grep -v '^zip_update/' \
    | grep -v '\.gitignore' \
    | grep -v '^\s*$' \
    || true)

if [ -z "$FILTERED" ]; then
    echo "⚠️  没有需要打包的改动文件，退出。"
    exit 0
fi

# ── 3. 打印文件列表 ────────────────────────────────────────────────────────────
echo "📦 打包以下改动文件："
echo "$FILTERED" | while read -r f; do echo "   ✔ $f"; done
echo ""

# ── 4. 创建 zip ────────────────────────────────────────────────────────────────
# zip 只接受存在的文件；过滤掉已被删除的条目
EXISTING=()
while IFS= read -r f; do
    [ -f "$f" ] && EXISTING+=("$f")
done <<< "$FILTERED"

if [ ${#EXISTING[@]} -eq 0 ]; then
    echo "⚠️  所有改动文件均已被删除，没有可打包的内容。"
    exit 0
fi

zip -r "$ZIP_NAME" "${EXISTING[@]}"

echo ""
echo "✅ 已生成：$ZIP_NAME"
echo "   包含 ${#EXISTING[@]} 个文件"
echo ""
echo "📤 推送到 GitHub 触发自动编译："
echo "   git add \"$ZIP_NAME\""
echo "   git commit -m \"🔧 patch $(date +%Y-%m-%d)\""
echo "   git push"
