#!build
# Fix GitHub sync: KP export + spurious CI builds

1. GitHubSyncViewModel: push now includes ALL knowledge point data
   (chapters, sections, points) inside state.json — no more stripping.
   Previously only isCustom=true points were pushed via separate grade
   files; since built-in KPs were removed, this left KPs out of sync.

2. GitHubSyncViewModel: all sync commit messages now include [skip ci]
   so GitHub Actions never triggers an APK build from a data-sync push.

3. AppRepository.importStateOnly: now also deletes and re-imports KP
   tables (kp_chapters, kp_sections, knowledge_points) in FK-safe order.
   Previously KP tables were untouched on pull, leaving stale data.

4. executePull: if state.json already contains KP data (new format),
   the separate kp_custom_*.json fetch is skipped. Legacy grade-file
   and single-file fallbacks are retained for old-format remotes.
