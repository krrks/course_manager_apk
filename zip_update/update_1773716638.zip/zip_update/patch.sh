#!/usr/bin/env bash
set -e

SCHEDULE="app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt"
ATTENDANCE="app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  PATCH: 拆分「时长+课题」行 → 两行独立"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 两个文件中的替换内容完全相同：
# 将「行4：课题⅔ + 时长⅓」的 Row 块替换为两个独立块（先时长，再课题）

OLD_BLOCK='        // ── 行4：课题⅔ + 时长⅓ ───────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(2f)) {
                FormTextField("课题", topic, { topic = it }, "本节课主题")
            }
            Box(Modifier.weight(1f)) {
                DurationChipsCompact(startTime = startTime, endTime = endTime) { endTime = it }
            }
        }'

NEW_BLOCK='        // ── 时长（独立行）────────────────────────────────────────────
        DurationChipsCompact(startTime = startTime, endTime = endTime) { endTime = it }

        // ── 课题（独立行）────────────────────────────────────────────
        FormTextField("课题", topic, { topic = it }, "本节课主题")'

python3 - <<PYEOF
import pathlib

old = '''        // ── 行4：课题⅔ + 时长⅓ ───────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.weight(2f)) {
                FormTextField("课题", topic, { topic = it }, "本节课主题")
            }
            Box(Modifier.weight(1f)) {
                DurationChipsCompact(startTime = startTime, endTime = endTime) { endTime = it }
            }
        }'''

new = '''        // ── 时长（独立行）────────────────────────────────────────────
        DurationChipsCompact(startTime = startTime, endTime = endTime) { endTime = it }

        // ── 课题（独立行）────────────────────────────────────────────
        FormTextField("课题", topic, { topic = it }, "本节课主题")'''

for filepath in [
    "app/src/main/java/com/school/manager/ui/screens/ScheduleScreen.kt",
    "app/src/main/java/com/school/manager/ui/screens/AttendanceScreen.kt",
]:
    p = pathlib.Path(filepath)
    src = p.read_text(encoding="utf-8")
    if old in src:
        p.write_text(src.replace(old, new), encoding="utf-8")
        print(f"✅ Patched: {filepath}")
    else:
        print(f"⚠️  Pattern not found in {filepath} — skipping")
PYEOF

echo "✅ Done"
