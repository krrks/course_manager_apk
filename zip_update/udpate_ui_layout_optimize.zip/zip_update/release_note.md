# 修改说明 — UI 空间优化：添加课程 & 添加上课记录表单

## 问题
表单中短字段（班级、教师、星期、编号、状态、日期、开始时间）各自独占整行，
而「课时时长」区块（含标题 + chips + 手动输入）却占据一整个大 Surface 块，
导致页面纵向高度过大、空间利用率低。

---

## 文件 1：ScheduleScreen.kt

### 新增组件

#### `StartTimeField`
- 将开始时间字段从 `TimeRangeRow` 中剥离为独立 Composable
- 带时钟 dial 选择器（IconButton → TimePickerDialog）
- 供 `AddScheduleDialog` 和 `AddAttendanceFromScheduleDialog` 各自在 `Row` 中独立摆放

#### `InlineDurationPicker`
- 将课时时长从原本独占一整个 `Surface` 块，重构为轻量内联组件
- 仍包含：预设快捷 chips（1h / 1.5h / 2h）、手动时+分输入、结束时间提示
- 无 Surface 背景包裹，可灵活嵌入 `Row` 或独占一行

### AddScheduleDialog 布局变更（原 6行 → 新 4行，节省 ~35% 高度）
| 原布局 | 新布局 |
|--------|--------|
| 班级（全宽） | 班级(2/3) + 教师(1/3) 同行 |
| 教师（全宽） | ↑ 合并至上行 |
| 星期（全宽） | 星期(1/3) + 课程编号(2/3) 同行 |
| 课程编号（全宽） | ↑ 合并至上行 |
| TimeRangeRow（含开始时间+课时时长大块） | 开始时间(1/3) + InlineDurationPicker(2/3) 同行 |
| ↑ 同上 | ↑ 合并至上行 |

### EditScheduleDialog 布局变更（同上）

### AddAttendanceFromScheduleDialog 布局变更（原 7行 → 新 5行，节省 ~30% 高度）
| 原布局 | 新布局 |
|--------|--------|
| 教师（全宽） | 教师（全宽，班级由 slot 带入不需选择） |
| 日期（全宽） | 日期(1/2) + 开始时间(1/2) 同行 |
| TimeRangeRow（开始时间+课时时长） | ↑ 合并至上行（开始时间）|
| ↑ | InlineDurationPicker（全宽，紧凑） |
| 状态（全宽） | 状态（全宽）|
| 课题（全宽） | 课题（全宽）|
| 出勤学生 | 出勤学生 |

### TimeRangeRow 保留
- 原 `TimeRangeRow` 完整保留，供 `AttendanceScreen.kt` 中引用（import 不变）

---

## 文件 2：AttendanceScreen.kt — AttendanceFormDialog

### 布局变更（原 8行 → 新 6行，节省 ~30% 高度）

| 原布局 | 新布局 |
|--------|--------|
| 编号（全宽） | 编号(1/2) + 状态(1/2) 同行 |
| 班级（全宽） | 班级(1/2) + 教师(1/2) 同行 |
| 科目 badge | 科目 badge（仍保留，在班级教师行下方） |
| 教师（全宽） | ↑ 合并至班级行 |
| 日期(1/2) + TimeRangeRow(1/2)（已有半宽优化） | 日期(1/2) + 开始时间(1/2) 同行 |
| 状态（全宽） | InlineDurationPicker（全宽，紧凑） |
| 课题（全宽） | 课题（全宽） |
| 出勤学生 | 出勤学生 |
| 备注（全宽） | 备注（全宽）|

### 新增引用
- `StartTimeField`（来自 ScheduleScreen.kt，internal 可见）
- `InlineDurationPicker`（来自 ScheduleScreen.kt，internal 可见）
- 需确认二者在同一模块中，internal 修饰符可跨文件访问

---

## 注意
- `AttendanceFormDialog_patch.kt` 仅为 patch 说明文件，实际需将内容替换进 `AttendanceScreen.kt` 中对应函数
- `ScheduleScreen.kt` 为完整替换文件，可直接覆盖原文件
- 所有 ViewModel 调用、数据模型、业务逻辑均未改动
