package com.school.manager.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.EventNote
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.school.manager.BuildConfig
import com.school.manager.ui.components.*
import com.school.manager.ui.theme.*
import com.school.manager.viewmodel.AppViewModel
import kotlinx.coroutines.delay

@Composable
fun ExportScreen(vm: AppViewModel, onOpenDrawer: () -> Unit = {}) {
    val context  = LocalContext.current
    val state    by vm.state.collectAsState()
    var toast    by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(toast) { if (toast != null) { delay(2500); toast = null } }

    var pendingJson  by remember { mutableStateOf<String?>(null) }
    var jsonFilename by remember { mutableStateOf("school_backup.json") }
    val createFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null && pendingJson != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(pendingJson!!.toByteArray()) }
                toast = "✅ 已导出 JSON"
            } catch (_: Exception) { toast = "❌ 导出失败" }
        }
    }
    fun exportWith(json: String, filename: String) { pendingJson = json; createFileLauncher.launch(filename) }

    val openFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val json = context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                toast = if (vm.importMerge(json)) "✅ 导入成功" else "❌ 导入失败：格式错误"
            } catch (_: Exception) { toast = "❌ 读取文件失败" }
        }
    }

    var pendingZipBytes by remember { mutableStateOf<ByteArray?>(null) }
    var zipFilename     by remember { mutableStateOf("school_backup.zip") }
    val createZipLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null && pendingZipBytes != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(pendingZipBytes!!) }
                toast = "✅ ZIP 备份已保存"
            } catch (_: Exception) { toast = "❌ 保存失败" }
        }
    }
    val openZipLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@rememberLauncherForActivityResult
                toast = if (vm.importFullBackupZip(context, bytes)) "✅ ZIP 恢复成功" else "❌ ZIP 恢复失败"
            } catch (_: Exception) { toast = "❌ 读取文件失败" }
        }
    }

    Scaffold(
        floatingActionButton = {
            ScreenSpeedDialFab(onOpenDrawer = onOpenDrawer)
        }
    ) { inner ->
        Box(Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        top    = inner.calculateTopPadding() + 8.dp,
                        bottom = inner.calculateBottomPadding() + 80.dp,
                        start  = 16.dp, end = 16.dp
                    )
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("数据管理", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

                // ── Full backup ───────────────────────────────────────────────
                Text("📦 完整备份", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                IoCard(Icons.Default.FolderZip, "导出 ZIP 备份", FluentBlue,
                    "包含所有数据及头像图片") {
                    val bytes = vm.exportFullBackupZip(context)
                    if (bytes != null) { pendingZipBytes = bytes; createZipLauncher.launch("school_backup.zip") }
                    else toast = "❌ 备份失败"
                }
                IoCard(Icons.Default.Restore, "恢复 ZIP 备份", FluentGreen,
                    "从 ZIP 文件恢复所有数据（合并模式）") { openZipLauncher.launch(arrayOf("application/zip")) }

                HorizontalDivider(color = FluentBorder)

                // ── JSON export ───────────────────────────────────────────────
                Text("📄 JSON 导出", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                IoCard(Icons.Outlined.Download, "导出完整数据", FluentBlue, "导出全部数据为 JSON 文件") {
                    exportWith(vm.exportFullStateJson(), "school_full.json")
                }
                IoCard(Icons.AutoMirrored.Outlined.EventNote, "导出课表 JSON", FluentPurple, "全部课程安排") {
                    exportWith(vm.exportScheduleJson(null), "school_schedule.json")
                }
                IoCard(Icons.Outlined.AssignmentTurnedIn, "导出出勤记录 JSON", FluentGreen, "全部上课记录") {
                    exportWith(vm.exportAttendanceJson(null), "school_attendance.json")
                }

                HorizontalDivider(color = FluentBorder)

                // ── Import ────────────────────────────────────────────────────
                Text("📥 导入", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                IoCard(Icons.Outlined.Upload, "导入 JSON（合并）", FluentAmber,
                    "从 JSON 文件合并数据，不覆盖已有记录") { openFileLauncher.launch(arrayOf("application/json")) }

                HorizontalDivider(color = FluentBorder)

                // ── Danger zone ───────────────────────────────────────────────
                Text("⚠️ 危险操作", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                var confirmReset by remember { mutableStateOf(false) }
                if (!confirmReset) {
                    IoCard(Icons.Default.DeleteForever, "重置为示例数据", Color(0xFFE53935),
                        "清空所有数据并恢复为预设示例（不可撤销）") { confirmReset = true }
                } else {
                    Surface(shape = RoundedCornerShape(16.dp),
                        color = Color(0xFFFFEBEE), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("确定要清空所有数据吗？此操作不可撤销。",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFFB71C1C), fontWeight = FontWeight.Medium)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(onClick = { confirmReset = false },
                                    modifier = Modifier.weight(1f)) { Text("取消") }
                                Button(onClick = { vm.resetToSampleData(); confirmReset = false },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))) {
                                    Text("确认重置", color = Color.White)
                                }
                            }
                        }
                    }
                }

                // ── FIX 3: version from BuildConfig — always matches the release tag ──
                Spacer(Modifier.height(8.dp))
                Text(
                    text      = "智慧课务管理  v${BuildConfig.VERSION_NAME}",
                    style     = MaterialTheme.typography.bodySmall,
                    color     = FluentMuted,
                    textAlign = TextAlign.Center,
                    modifier  = Modifier.fillMaxWidth()
                )
            }

            // ── Toast ─────────────────────────────────────────────────────────
            toast?.let { msg ->
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                    Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF323232),
                        modifier = Modifier.padding(bottom = 32.dp)) {
                        Text(msg, color = Color.White,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp))
                    }
                }
            }
        }
    }
}

// ── IoCard ─────────────────────────────────────────────────────────────────────

@Composable
private fun IoCard(
    icon: ImageVector, title: String, color: Color,
    subtitle: String = "", onClick: () -> Unit
) {
    Surface(
        shape           = RoundedCornerShape(16.dp),
        color           = color.copy(alpha = 0.08f),
        modifier        = Modifier.fillMaxWidth(),
        onClick         = onClick
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, null, tint = color, modifier = Modifier.size(28.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold, color = color)
                if (subtitle.isNotBlank())
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = FluentMuted)
            }
            Icon(Icons.Default.ChevronRight, null, tint = color.copy(alpha = 0.5f))
        }
    }
}
