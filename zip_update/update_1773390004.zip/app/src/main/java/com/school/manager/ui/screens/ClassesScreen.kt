package com.school.manager.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.school.manager.data.*
import com.school.manager.ui.components.*
import com.school.manager.ui.theme.*
import com.school.manager.viewmodel.AppViewModel

@Composable
fun ClassesScreen(vm: AppViewModel, onOpenDrawer: () -> Unit = {}) {
    val state   by vm.state.collectAsState()
    var showAdd  by remember { mutableStateOf(false) }
    var viewing  by remember { mutableStateOf<SchoolClass?>(null) }
    var editing  by remember { mutableStateOf<SchoolClass?>(null) }

    Scaffold(
        floatingActionButton = {
            ScreenSpeedDialFab(
                addLabel     = "添加班级",
                addIcon      = Icons.Default.Add,
                onAdd        = { showAdd = true },
                onOpenDrawer = onOpenDrawer
            )
        }
    ) { inner ->
        LazyColumn(
            contentPadding = PaddingValues(
                start  = 12.dp,
                end    = 12.dp,
                top    = inner.calculateTopPadding() + 8.dp,
                bottom = inner.calculateBottomPadding() + 80.dp
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (state.classes.isEmpty()) item { EmptyState("🏫", "暂无班级") }
            else items(state.classes) { cls ->
                ClassCard(cls, state, vm,
                    onClick  = { viewing = cls },
                    onEdit   = { editing = cls },
                    onDelete = { vm.deleteSchoolClass(cls.id) })
            }
        }
    }

    viewing?.let { cls ->
        ClassDetailDialog(cls, state, vm,
            onDismiss = { viewing = null },
            onEdit    = { editing = cls; viewing = null },
            onDelete  = { vm.deleteSchoolClass(cls.id); viewing = null })
    }
    editing?.let { cls ->
        ClassFormDialog("编辑班级", cls, state, vm,
            onDismiss = { editing = null },
            onSave    = { updated -> vm.updateSchoolClass(updated); editing = null })
    }
    if (showAdd) {
        ClassFormDialog("添加班级", null, state, vm,
            onDismiss = { showAdd = false },
            onSave    = { cls ->
                vm.addSchoolClass(cls.name, cls.grade, cls.count, cls.headTeacherId, cls.subject, cls.code)
                showAdd = false
            })
    }
}

// ── Class card ────────────────────────────────────────────────────────────────

@Composable
private fun ClassCard(
    cls: SchoolClass, state: AppState, vm: AppViewModel,
    onClick: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit
) {
    val students    = state.students.filter { it.classIds.contains(cls.id) }
    val headTeacher = state.teachers.firstOrNull { it.id == cls.headTeacherId }
    val ratio       = if (cls.count > 0) students.size.toFloat() / cls.count else 0f

    FluentCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(cls.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(cls.grade, style = MaterialTheme.typography.bodySmall, color = FluentMuted)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, "编辑", tint = FluentBlue, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, "删除", tint = FluentRed, modifier = Modifier.size(18.dp))
                    }
                }
            }

            if (cls.subject.isNotBlank()) {
                Surface(shape = RoundedCornerShape(6.dp), color = FluentBlueLight) {
                    Text(cls.subject,
                        style = MaterialTheme.typography.labelSmall, color = FluentBlue,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                if (headTeacher != null)
                    Text("👩‍🏫 ${headTeacher.name}", style = MaterialTheme.typography.bodySmall, color = FluentMuted)
                Text("👥 ${students.size} / ${cls.count} 人",
                    style = MaterialTheme.typography.bodySmall, color = FluentMuted)
            }

            LinearProgressIndicator(
                progress         = { ratio.coerceIn(0f, 1f) },
                modifier         = Modifier.fillMaxWidth().height(4.dp),
                color            = FluentBlue,
                trackColor       = FluentBorder,
                strokeCap        = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}

// ── Detail dialog ─────────────────────────────────────────────────────────────

@Composable
private fun ClassDetailDialog(
    cls: SchoolClass, state: AppState, vm: AppViewModel,
    onDismiss: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit
) {
    val sts         = state.students.filter { it.classIds.contains(cls.id) }
    val headTeacher = state.teachers.firstOrNull { it.id == cls.headTeacherId }

    FluentDialog(title = "班级详情", onDismiss = onDismiss) {
        DetailRow("班级名称", cls.name)
        DetailRow("年级",     cls.grade)
        if (cls.subject.isNotBlank()) DetailRow("科目", cls.subject)
        if (cls.code.isNotBlank())    DetailRow("编号", cls.code)
        DetailRow("班主任",   headTeacher?.name ?: "未设置")
        DetailRow("编制人数", "${cls.count} 人")
        DetailRow("在籍学生", "${sts.size} 人")
        if (sts.isNotEmpty()) {
            SectionHeader("班级学生")
            androidx.compose.foundation.layout.FlowRow(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                sts.forEach { s -> ColorChip(s.name, FluentBlue) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onEdit, shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)) { Text("✏️ 编辑") }
            OutlinedButton(onClick = onDelete, shape = RoundedCornerShape(12.dp),
                colors   = ButtonDefaults.outlinedButtonColors(contentColor = FluentRed),
                modifier = Modifier.weight(1f)) { Text("删除") }
        }
    }
}

// ── Form dialog ───────────────────────────────────────────────────────────────

@Composable
private fun ClassFormDialog(
    title: String, initial: SchoolClass?,
    state: AppState, vm: AppViewModel,
    onDismiss: () -> Unit, onSave: (SchoolClass) -> Unit
) {
    val existingSubjects = remember(state) {
        (state.subjects.map { it.name } +
         state.classes.map { it.subject }.filter { it.isNotBlank() })
            .distinct().sorted()
    }

    var name    by remember { mutableStateOf(initial?.name    ?: "") }
    var grade   by remember { mutableStateOf(initial?.grade   ?: GRADES[0]) }
    var count   by remember { mutableStateOf(initial?.count?.toString() ?: "") }
    var teacher by remember { mutableStateOf(
        state.teachers.firstOrNull { it.id == initial?.headTeacherId }?.name ?: "") }
    var subject by remember { mutableStateOf(initial?.subject ?: "") }
    var code    by remember { mutableStateOf(initial?.code    ?: genCode("C")) }

    val initialStudentIds = remember(state, initial) {
        if (initial == null) emptySet()
        else state.students.filter { it.classIds.contains(initial.id) }.map { it.id }.toSet()
    }
    var selectedStudents by remember { mutableStateOf(initialStudentIds) }

    // ── FIX 2: grade filter for student picker ────────────────────────────────
    var studentGradeFilter by remember { mutableStateOf("") }

    FluentDialog(title = title, onDismiss = onDismiss, onConfirm = {
        if (name.isNotBlank()) {
            val tId = state.teachers.firstOrNull { it.name == teacher }?.id
            val savedClass = SchoolClass(
                id            = initial?.id ?: System.currentTimeMillis(),
                name          = name.trim(),
                grade         = grade,
                count         = count.toIntOrNull() ?: 0,
                headTeacherId = tId,
                subject       = subject.trim(),
                code          = code.trim()
            )
            if (initial != null) {
                val classId = initial.id
                (selectedStudents - initialStudentIds).forEach { sId ->
                    val s = state.students.find { it.id == sId }
                    if (s != null && !s.classIds.contains(classId))
                        vm.updateStudent(s.copy(classIds = s.classIds + classId))
                }
                (initialStudentIds - selectedStudents).forEach { sId ->
                    val s = state.students.find { it.id == sId }
                    if (s != null)
                        vm.updateStudent(s.copy(classIds = s.classIds.filter { it != classId }))
                }
            }
            onSave(savedClass)
        }
    }) {
        FluentTextField("班级名称", name, { name = it })
        DropdownField("年级", grade, GRADES) { grade = it }
        FluentTextField("编制人数", count, { count = it })
        DropdownField("班主任", teacher,
            listOf("") + state.teachers.map { it.name }) { teacher = it }
        AutocompleteTextField("科目", subject, existingSubjects) { subject = it }
        FluentTextField("班级编号", code, { code = it })

        // Student section (edit mode only)
        if (initial != null && state.students.isNotEmpty()) {
            SectionHeader("班级学生")
            Text("勾选属于此班级的学生",
                style    = MaterialTheme.typography.bodySmall,
                color    = FluentMuted,
                modifier = Modifier.padding(horizontal = 16.dp))

            // ── FIX 2: Grade filter chips ─────────────────────────────────────
            val availableGrades = remember(state.students) {
                state.students.map { it.grade }.distinct().sorted()
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = studentGradeFilter.isEmpty(),
                    onClick  = { studentGradeFilter = "" },
                    label    = { Text("全部") },
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FluentBlue,
                        selectedLabelColor     = Color.White)
                )
                availableGrades.forEach { g ->
                    FilterChip(
                        selected = studentGradeFilter == g,
                        onClick  = { studentGradeFilter = if (studentGradeFilter == g) "" else g },
                        label    = { Text(g) },
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FluentBlue,
                            selectedLabelColor     = Color.White)
                    )
                }
            }

            // Student chips — filtered by grade
            val filteredStudents = if (studentGradeFilter.isEmpty()) state.students
                                   else state.students.filter { it.grade == studentGradeFilter }

            if (filteredStudents.isEmpty()) {
                Text("该年级暂无学生", style = MaterialTheme.typography.bodySmall,
                    color = FluentMuted, modifier = Modifier.padding(horizontal = 16.dp))
            } else {
                androidx.compose.foundation.layout.FlowRow(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement   = Arrangement.spacedBy(4.dp)
                ) {
                    filteredStudents.forEach { s ->
                        val isSelected = s.id in selectedStudents
                        FilterChip(
                            selected = isSelected,
                            onClick  = {
                                selectedStudents = if (isSelected)
                                    selectedStudents - s.id
                                else
                                    selectedStudents + s.id
                            },
                            label = { Text(s.name) }
                        )
                    }
                }
            }
        }
    }
}
