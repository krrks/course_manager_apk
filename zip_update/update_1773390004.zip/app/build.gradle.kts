plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.school.manager"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.school.manager"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "1.006"   // CI overwrites this from the computed release tag (e.g. v1.006 → 1.006)
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
    }

    // ── 签名配置 ──────────────────────────────────────────────────────────────
    val keystorePath  = System.getenv("KEYSTORE_PATH")
    val storePassword = System.getenv("KEYSTORE_STORE_PASSWORD")
    val keyAlias      = System.getenv("KEYSTORE_KEY_ALIAS")
    val keyPassword   = System.getenv("KEYSTORE_KEY_PASSWORD")
    val ksFile        = if (keystorePath != null) file(keystorePath) else null
    val useReleaseKey = keystorePath  != null && storePassword != null &&
                        keyAlias      != null && keyPassword   != null &&
                        ksFile        != null && ksFile.exists()

    if (useReleaseKey) {
        signingConfigs {
            create("release") {
                storeFile          = ksFile
                this.storePassword = storePassword
                this.keyAlias      = keyAlias
                this.keyPassword   = keyPassword
            }
        }
        println("✅ Release signing: using $keystorePath (alias=$keyAlias)")
    } else {
        println("⚠️  Release signing: env vars missing or jks not found — APK will be signed with debug key")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = if (useReleaseKey)
                signingConfigs.getByName("release")
            else
                signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose    = true
        buildConfig = true   // enables BuildConfig.VERSION_NAME in app code
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.gson)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}
