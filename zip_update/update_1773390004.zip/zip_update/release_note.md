# Patch Notes — UI优化 + 版本号同步

## 修复 1：添加上课记录 — 压缩表单高度

- **日期 + 开始时间** 并排显示在同一行（两个等宽输入框，点击日历/时钟图标各自弹出选择器）
- **课题 + 备注** 并排显示在同一行（两个等宽输入框）
- 减少了约 2 个输入框高度的竖向滚动，表单更紧凑
- 影响文件：`ScheduleScreen.kt`（`TimeRangeRow` 新增可选 `date/onDateChange` 参数）、`AttendanceScreen.kt`（`AttendanceFormDialog` 调用新接口）

## 修复 2：编辑班级 — 学生选择按年级筛选

- 勾选班级学生区域顶部新增年级筛选 FilterChip 行（全部 / 高一 / 高二 / …）
- 按实际学生数据的年级动态生成，选中某年级后只显示该年级学生
- 影响文件：`ClassesScreen.kt`（`ClassFormDialog`）

## 修复 3：软件版本号与 Release 一致

- `ExportScreen.kt`：移除硬编码 `APP_VERSION`，改为读取 `BuildConfig.VERSION_NAME`
- `app/build.gradle.kts`：开启 `buildConfig = true`，确保 `BuildConfig` 类生成
- `.github/workflows/build.yml`：
  - 将「计算版本号」步骤移至编译之前
  - 新增「写入版本号」步骤，在编译前将 `versionName`（如 `1.006`）和 `versionCode`（如 `6`）
    自动 `sed` 写入 `app/build.gradle.kts`
  - 结果：APK 里的 `BuildConfig.VERSION_NAME` 与 GitHub Release 标签完全一致

## 修复 4：课表日历 — 筛选标题独占屏幕顶部一行

- 「王老师的课表」等标题不再悬浮在日历内部，而是作为独立的蓝色浅底横条
  显示在 Scaffold 内容区最顶部、日历格子外面，占满一行宽度
- 不筛选（全部课表）时标题横条不显示，日历从顶部开始
- 影响文件：`ScheduleScreen.kt`（`ScheduleScreen` Scaffold body 改用 `Column` 布局）
